public interface Calcula {
    public float calculaSalario();
}
