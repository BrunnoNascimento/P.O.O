public class Medicamento {
    String nome;
    String marca;
    int quantidade;
}
