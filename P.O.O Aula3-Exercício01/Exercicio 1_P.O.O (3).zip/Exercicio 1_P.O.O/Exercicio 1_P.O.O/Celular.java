public class Celular {
    float valor;
    String marca;
    String modelo;
}
