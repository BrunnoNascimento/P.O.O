public interface Imprimivel {
    //constante
    char nlin = '\n';
    
    public String formatoString();
    public void formatoSystemOut();
}
