import javax.swing.JOptionPane;

public class usaChamado {
    public static void main(String[] args) {
        Chamado ch1 = new Chamado("Brunno", "Peça quebrada");
        Chamado ch2 = new Chamado(JOptionPane.showInputDialog(null, "Digite seu nome: "), JOptionPane.showInputDialog(null, "Digite o seu problema: "));


        ch1.getCustoatendimento(JOptionPane.showInputDialog(null, "Digite o custo do seu atendimento: "));
        ch1.getCustopecas(JOptionPane.showInputDialog(null, "Digite o custo da peça: "));
        ch1.getProblema(JOptionPane.showInputDialog(null, "Digite o custo da peça: "));

        ch2.getCustoatendimento();
        ch2.getCustopecas();
        ch2.getProblema();

        ch1.maiorCusto(ch2);
        ch1.menorValorPeca(ch2);

        ch2.maiorCusto(ch2);
        ch2.menorValorPeca(ch2);

        ch1.exibir();
        ch2.exibir();

    }
}
