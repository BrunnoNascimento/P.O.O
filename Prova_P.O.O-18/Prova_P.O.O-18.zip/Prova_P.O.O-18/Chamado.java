import javax.swing.JOptionPane;

public class Chamado{
    private String nomecliente;
    private String problema;
    private double custoatendimento;
    private double custopecas;

    //construtores
    Chamado(String nomecliente, String problema){
        this.nomecliente = nomecliente;
        this.problema = problema;
    }

    Chamado(String nomecliente, String problema, double custoatendimento, double custopecas){
        this.nomecliente = nomecliente;
        this.problema = problema;
        this.custoatendimento = custoatendimento;
        this.custopecas = custopecas;
    }

    //get's and set's....
    public String getNomecliente() {
        JOptionPane.showInputDialog("Digite aqui o seu nome:");
        return nomecliente;
    }
    public void setNomecliente(String nomecliente) {
        this.nomecliente = nomecliente;
    }
    public String getProblema() {
        JOptionPane.showInputDialog("Digite aqui o seu problema:");
        return problema;
    }
    public void setProblema(String problema) {
        this.problema = problema;
    }
    public double getCustoatendimento() {
        JOptionPane.showInputDialog("Digite aqui o custo do atendimento:");
        return custoatendimento;
    }
    public void setCustoatendimento(double custoatendimento) {
        this.custoatendimento = custoatendimento;
    }
    public double getCustopecas() {
        JOptionPane.showInputDialog("Digite aqui o custo das peças:");
        return custopecas;
    }
    public void setCustopecas(double custopecas) {
        this.custopecas = custopecas;
    }

    //métodos.....
    public void acrescentaPeca(double valor){
        double v1;
        v1 = valor + getCustopecas();
    }

    public void acrescentaPeca(int qtde, double valor){
        int quantidade;
        double valor1;
        
        quantidade = quantidade*valor1;
        quantidade = quantidade+getCustopecas();
    }

    public double calculaTotal(){
        double atendimento;

        atendimento = getCustoatendimento()+getCustopecas();
        return atendimento;
    }

    public String menorValorPeca(Chamado ch){
        Chamado ch1;
        
        if (custopecas < ch1) {
            return nomecliente;
        }
    }
    
    public Chamado maiorCusto(Chamado ch){
        Chamado ch1;

    }

    public String exibir(){
        JOptionPane.showMessageDialog(null, "Nome do cliente:" + nomecliente + "\nProblema: " + problema + "\nCusto do atendimento: " + custoatendimento + "\nCusto de atendimento: " + custoatendimento + "\nCusto das peças: " + custopecas);
        
    }
}